#!/usr/bin/env python3
"""
Interactive conversation client for the production GFG Agent (Custom Endpoint).
- Uses the custom /chat/stream endpoint that properly handles PostgreSQL persistence
- Streams responses and prints assistant messages
- Tracks TTFT (Time To First Token)

Usage:
  # Using .env (auto-loaded)
  python test_gfg_agent.py

  # Or via args
  python test_gfg_agent.py --url http://localhost:8000/chat/stream
"""

import argparse
import asyncio
import json
import os
import sys
import time
import uuid
from typing import Any

# Auto-load .env
try:
    from dotenv import load_dotenv

    load_dotenv(override=True)
except Exception:
    pass

try:
    import httpx
except ImportError:
    print("Missing dependency 'httpx'. Install with: pip install httpx", file=sys.stderr)
    sys.exit(1)

DEFAULT_URL = os.getenv("GRAPH_URL", "http://localhost:8000/chat/stream")
DEFAULT_TOKEN = os.getenv("GRAPH_API_KEY", "")


def build_payload(user_input: str, thread_id: str) -> dict[str, Any]:
    """Build request payload for custom /chat/stream endpoint"""
    return {
        "input": {
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": user_input}],
                }
            ],
            # "caller_number": "+19296683132"  # Hardcoded phone number for testing
        },
        "thread_id": thread_id,
    }


def extract_message_content(data: dict[str, Any]) -> str | None:
    """Extract message content from the response data"""
    try:
        # Our custom endpoint returns: {"messages": [...]} directly
        messages = data.get("messages", [])

        # Find the latest AI message
        for msg in reversed(messages):  # Check from latest to oldest
            if msg.get("type") == "ai":
                content = msg.get("content")
                if isinstance(content, str) and content.strip():
                    return content
        return None
    except Exception:
        return None


async def stream_conversation(url: str, token: str, user_input: str, thread_id: str) -> str | None:
    """
    Stream conversation using the custom /chat/stream endpoint

    Returns:
        Optional[str]: The complete assistant response, or None if no response
    """
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    payload = build_payload(user_input, thread_id)

    # Debug: print request details
    masked = (token[:6] + "..." + token[-4:]) if token and len(token) > 10 else (token or "(none)")
    print(f"\nDEBUG Request → {url}")
    print(f"  token: {masked}")
    print(f"  thread_id: {thread_id}")
    print(f"  payload: {json.dumps(payload, indent=2)}")

    start_time = time.time()
    first_token_time: float | None = None
    assistant_response = ""  # Accumulate the full response for logging
    tool_inputs_cache = {}  # Cache tool inputs from tool_start events

    async with httpx.AsyncClient(timeout=30.0) as client:
        async with client.stream("POST", url, json=payload, headers=headers) as response:
            if response.status_code != 200:
                error_text = await response.aread()
                print(f"Error {response.status_code}: {error_text.decode()}")
                return

            async for line in response.aiter_lines():
                if not line.strip():
                    continue

                if line.startswith("data: "):
                    data_str = line[6:]  # Remove "data: " prefix

                    if data_str == "[DONE]":
                        break

                    try:
                        data = json.loads(data_str)

                        # Check for errors
                        if "error" in data:
                            print(f"\nError: {data['error']}")
                            continue

                        # Handle different event types
                        event_type = data.get("type")

                        if event_type == "say":
                            # Handle "say" messages from tools
                            say_message = data.get("message", "")
                            if say_message:
                                print(f"\n💬 Tool: {say_message}", flush=True)
                            continue

                        elif event_type == "tool_start":
                            # Cache tool input for when tool_end arrives
                            tool_name = data.get("tool_name", "Unknown")
                            tool_inputs_cache[tool_name] = data.get("parameters", {})
                            print(f"\n⚙️  Executing: {tool_name}...", flush=True)
                            continue

                        elif event_type == "tool_end":
                            # Handle tool completion events
                            tool_name = data.get("tool_name", "Unknown")
                            print(f"\n🔧 Tool: {tool_name} ✓", flush=True)

                            # Clean up cache
                            tool_inputs_cache.pop(tool_name, None)
                            continue

                        elif event_type == "token":
                            # Handle token-level streaming (like ChatGPT)
                            content = data.get("content", "")

                            if content:
                                if first_token_time is None:
                                    first_token_time = time.time()
                                    ttft = first_token_time - start_time
                                    print(
                                        f"\n🎯 TTFT: {ttft:.3f}s\n🤖 Agent: ",
                                        end="",
                                        flush=True,
                                    )

                                # Stream token by token and accumulate
                                print(content, end="", flush=True)
                                assistant_response += content
                            continue

                        elif event_type == "completion":
                            # Handle completion event
                            if first_token_time is not None:
                                print()  # New line after completion
                            continue

                        elif event_type == "flush":
                            # Handle flush events
                            print("", flush=True)
                            continue

                        # Fallback: Extract regular message content (for compatibility)
                        content = extract_message_content(data)
                        if content:
                            if first_token_time is None:
                                first_token_time = time.time()
                                ttft = first_token_time - start_time
                                print(
                                    f"\n🎯 TTFT: {ttft:.3f}s\n🤖 Agent: {content}",
                                    flush=True,
                                )
                                assistant_response = content
                            else:
                                print(content, end="", flush=True)
                                assistant_response += content

                    except json.JSONDecodeError as e:
                        print(f"\nJSON decode error: {e}")
                        continue

    if first_token_time is None:
        print("\n(No assistant response received)")
        return None
    else:
        print()  # newline after response
        return assistant_response.strip() if assistant_response else None


async def main() -> int:
    parser = argparse.ArgumentParser(description="Interactive remote conversation with GFG Agent (Custom Endpoint)")
    parser.add_argument(
        "--url",
        default=DEFAULT_URL,
        help="Chat stream URL, e.g., http://localhost:8000/chat/stream",
    )
    parser.add_argument("--token", default=DEFAULT_TOKEN, help="Bearer token (GRAPH_API_KEY)")
    parser.add_argument("--thread", default=None, help="Optional thread_id for persistence")
    args = parser.parse_args()

    if not args.token:
        print("Warning: No token provided. API may still work without authentication.")

    thread_id = args.thread or f"gfg-thread-{uuid.uuid4()}"

    print("🤖 GFG Agent - Custom Endpoint Client")
    print(f"Connected to: {args.url}")
    print(f"Thread ID: {thread_id}")
    print("Type 'exit' to quit.")

    while True:
        try:
            user_input = input("\n👤 Enter your query: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if user_input.lower() in {"exit", "quit", "q", "bye"}:
            break

        try:
            # Stream the conversation and get the assistant's response
            await stream_conversation(args.url, args.token, user_input, thread_id)

        except Exception as e:
            print(f"Error during streaming: {e}")

    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
