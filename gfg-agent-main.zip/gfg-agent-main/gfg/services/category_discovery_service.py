"""
Category Discovery Service
Contains business logic for category discovery and decision tree navigation.
"""

from typing import Any

from gfg.external_api.middleware.product_api import get_middleware_api
from gfg.utils.logger import get_logger

logger = get_logger(__name__)

# Domain to product families mapping based on the decision tree image
DOMAIN_PRODUCT_FAMILIES = {
    "Workplace": [
        "Workplace Seating",
        "Workplace Filing and Storage",
        "Workplace Desking and Tables",
    ],
    "Education": [
        "Education Seating",
        "Education Desking and Tables",
        "Education Filing and Storage"
    ],
    "Healthcare": [
        "Healthcare Seating",
        "Healthcare Desking and Tables",
        "Healthcare Patient and Resident",
        # "Healthcare Filing and Storage"
    ],
}


class CategoryDiscoveryService:
    """
    Service class for category discovery and decision tree navigation operations.
    """

    def __init__(self):
        """Initialize the CategoryDiscoveryService."""
        self.logger = get_logger(__name__)
        self.domain_product_families = DOMAIN_PRODUCT_FAMILIES

    async def get_decision_domains(self) -> dict:
        """
        Get available domains for furniture selection.

        Returns:
            A dictionary containing success status and list of domains
        """
        try:
            self.logger.info("GET_DECISION_DOMAINS: Fetching available domains")

            domains = ["Workplace", "Education", "Healthcare"]

            next_action = "Say EXACTLY this to the user (no additions): 'Hi! I'm here to help you find the right furniture. Are you looking for furniture for a workplace, an educational setting, or a healthcare facility?'\n\n"
            next_action += "ONLY IF user responds with confusion or asks what these mean, THEN provide clarifying examples:\n"
            next_action += "- Workplace: offices, conference rooms, common areas\n"
            next_action += "- Education: classrooms, study areas, labs\n"
            next_action += "- Healthcare: hospitals, clinics, patient rooms\n\n"
            next_action += "**If user describes product details and none of these domains match**: Call transfer_to_product_suggestion_agent silently (no message to user).\n"
            next_action += "**If domain can be identified from their message**: Continue with get_decision_product_families tool."

            return {"success": True, "domains": domains, "next_action": next_action}

        except Exception as e:
            self.logger.error(f"GET_DECISION_DOMAINS: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "next_action": "There was an error fetching domains. Please try again.",
            }

    async def get_decision_product_families(self, domain: str) -> dict:
        """
        Get product families for a given domain.

        Args:
            domain: The domain (Workplace, Education, Healthcare)

        Returns:
            A dictionary containing success status and list of product families
        """
        try:
            self.logger.info(f"GET_DECISION_PRODUCT_FAMILIES: Fetching product families for domain: {domain}")

            # Normalize domain name
            domain_normalized = domain.strip().title()

            if domain_normalized not in self.domain_product_families:
                return {
                    "success": False,
                    "error": f"Invalid domain: {domain}",
                    "next_action": f"The domain '{domain}' is not recognized. Please choose from: Workplace, Education, or Healthcare.",
                }

            product_families = self.domain_product_families[domain_normalized]

            families_list = ", ".join(product_families)
            next_action = f"For the {domain_normalized} domain, we have the following product families available: {families_list}. Which product family are you interested in?"

            return {
                "success": True,
                "domain": domain_normalized,
                "product_families": product_families,
                "next_action": next_action,
            }

        except Exception as e:
            self.logger.error(f"GET_DECISION_PRODUCT_FAMILIES: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "next_action": f"There was an error fetching product families for {domain}. Please try again.",
            }

    async def get_decision_step(self, domain: str, product_family: str, navigation_path: list[str]) -> dict:
        """
        Navigate through the decision tree and get the current step.

        Args:
            domain: The domain (Workplace, Education, Healthcare)
            product_family: The product family (e.g., "Desking + Tables", "Seating", "Storage")
            navigation_path: List of node IDs representing the path taken (e.g., ["1", "1A", "2"])

        Returns:
            A dictionary containing current node information and next action
        """
        try:
            self.logger.info(
                f"GET_DECISION_STEP: domain={domain}, product_family={product_family}, navigation_path={navigation_path}"
            )

            # Fetch decision trees from API
            api = get_middleware_api()
            result = await api.get_decision_trees()

            if not result.get("success"):
                self.logger.error("GET_DECISION_STEP: Failed to fetch decision trees")
                return {
                    "success": False,
                    "error": "Failed to fetch decision trees",
                    "next_action": "Unable to load decision tree data. Please try again later.",
                }

            decision_trees = result["data"]

            # Normalize inputs
            domain_normalized = domain.strip().title()

            # Find the correct decision tree based on domain and product_family
            matching_tree = None
            for tree in decision_trees:
                # Match by domain and sheet (sheet corresponds to product_family)
                if tree.get("domains") == domain_normalized and tree.get("sheet") == product_family:
                    matching_tree = tree
                    break

            if not matching_tree:
                self.logger.warning(
                    f"GET_DECISION_STEP: No decision tree found for domain={domain_normalized}, product_family={product_family}"
                )
                return {
                    "success": False,
                    "error": f"No decision tree found for {domain_normalized} - {product_family}",
                    "next_action": f"Sorry, we don't have a decision tree for {product_family} in the {domain_normalized} domain yet.",
                }

            nodes = matching_tree.get("nodes", [])

            # If navigation_path is empty, start with the first node
            if not navigation_path or len(navigation_path) == 0:
                # Find the first node (ID "1")
                current_node = None
                for node in nodes:
                    if node.get("id") == "1":
                        current_node = node
                        break

                if not current_node:
                    return {
                        "success": False,
                        "error": "Starting node not found",
                        "next_action": "Unable to start the decision tree. Please try again.",
                    }

                return self._format_node_response(current_node, domain_normalized, product_family)

            # Navigate to the current node based on navigation_path
            # The last item in navigation_path is the current node ID
            current_node_id = navigation_path[-1]

            current_node = None
            for node in nodes:
                if node.get("id") == current_node_id:
                    current_node = node
                    break

            if not current_node:
                self.logger.error(f"GET_DECISION_STEP: Node {current_node_id} not found in tree")
                return {
                    "success": False,
                    "error": f"Node {current_node_id} not found",
                    "next_action": "Navigation error occurred. Please start over.",
                }

            return self._format_node_response(current_node, domain_normalized, product_family)

        except Exception as e:
            self.logger.error(f"GET_DECISION_STEP: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "next_action": "There was an error navigating the decision tree. Please try again.",
            }

    def _format_node_response(self, node: dict[str, Any], domain: str, product_family: str) -> dict:
        """
        Helper method to format the node response based on node type.

        Args:
            node: The current node from the decision tree
            domain: The domain being explored
            product_family: The product family being explored

        Returns:
            Formatted response dictionary
        """
        node_type = node.get("type")
        # node_id = node.get("id")

        if node_type == "question":
            # Format question with options
            question_text = node.get("text", "")
            options = node.get("options", [])

            # Build options text
            options_list = []
            for opt in options:
                # option_id = opt.get("id")
                option_text = opt.get("text")
                next_node = opt.get("next")
                options_list.append(
                    {
                        # "id": option_id,
                        "text": option_text,
                        "next": next_node,
                    }
                )

            # Format for display
            options_display = "\n".join([f"- {opt['text']}" for opt in options_list])

            next_action = f"Ask user: {question_text}\n\nOptions:\n{options_display}\n\n"
            next_action += "Wait for user's choice, then call get_decision_step again with the chosen option's 'next' value added to navigation_path.\n\n"
            next_action += "IMPORTANT: DO NOT transfer to product_suggestion_agent. Continue with get_decision_step until you receive a 'recommendation' node type."

            self.logger.info(f"\n\nFORMAT_NODE_RESPONSE: node_type='question'\nOptions: {options_list}\n\n")
            self.logger.info(f"\n\nNext action: {next_action}\n\n")

            return {
                "success": True,
                "node_type": "question",
                # "node_id": node_id,
                # "question": question_text,
                "options": options_list,
                "next_action": next_action,
            }

        elif node_type == "recommendation":
            # This is the final step - extract categories
            options = node.get("options", [])

            if not options or len(options) == 0:
                return {
                    "success": False,
                    "error": "No recommendations found",
                    "next_action": "Unable to determine the category. Please start over.",
                }

            # Get the recommendation
            recommendation = options[0]
            # final_recommendation = recommendation.get("final_recommendation", "")
            maps_to = recommendation.get("maps_to", {})
            categories = maps_to.get("category", [])

            if not categories or len(categories) == 0:
                return {
                    "success": False,
                    "error": "No categories found in recommendation",
                    "next_action": "Unable to determine the category. Please start over.",
                }

            # Format categories
            if len(categories) == 1:
                category_text = categories[0]
            else:
                category_text = ", ".join(categories)

            # Internal instruction - transfer WITHOUT user message
            next_action = "!!! DO NOT RESPOND TO USER !!!\n"
            next_action += "!!! DO NOT GENERATE ANY MESSAGE !!!\n\n"
            next_action += "ACTION 1: Call transfer_to_product_suggestion_agent tool RIGHT NOW.\n"
            next_action += f"ACTION 2: After transfer, immediately call get_products_by_category tool with categories: {category_text}"

            self.logger.info(f"\n\nFORMAT_NODE_RESPONSE: node_type='recommendation'\nCategories: {categories}\n\n")

            return {
                "success": True,
                "node_type": "recommendation",
                # "node_id": node_id,
                # "recommendation": final_recommendation,
                "categories": categories,
                "next_action": next_action,
            }

        else:
            return {
                "success": False,
                "error": f"Unknown node type: {node_type}",
                "next_action": "An error occurred. Please start over.",
            }


# Global singleton instance
_category_discovery_service = None


def get_category_discovery_service() -> CategoryDiscoveryService:
    """Get or create the global category discovery service instance."""
    global _category_discovery_service
    if _category_discovery_service is None:
        _category_discovery_service = CategoryDiscoveryService()
    return _category_discovery_service
