"""
Product Suggestion Service
Contains business logic for product suggestion operations.
"""

from gfg.external_api.middleware.product_api import get_middleware_api
from gfg.utils.constants import ALL_PRODUCT_CATEGORIES
from gfg.utils.logger import get_logger

logger = get_logger(__name__)


class ProductSuggestionService:
    """
    Service class for product suggestion operations.
    """

    def __init__(self):
        """Initialize the ProductSuggestionService."""
        self.logger = get_logger(__name__)

    def _get_alternative_categories_message(self, failed_categories: list[str]) -> str:
        """
        Generate a message showing available categories when requested categories have no products.
        Shows first 12 categories initially, with option to see more.

        Args:
            failed_categories: List of categories that had no products

        Returns:
            Formatted message with available categories
        """
        # Show first 12 categories initially
        initial_categories = ALL_PRODUCT_CATEGORIES[:12]
        remaining_categories = ALL_PRODUCT_CATEGORIES[12:]
        
        categories_list = "\n".join([f"{i+1}. {cat}" for i, cat in enumerate(initial_categories)])
        failed_text = ", ".join(failed_categories)

        message = f"""Tell the user - Based on your preference, unfortunately no product series were found for the categories: {failed_text}.

However, we have the following categories available:

{categories_list}

Which categories are you interested in? (You can select one or more)
If you'd like to see more category options, let me know and I'll show you the rest.

If the user asks to see more categories, show them the remaining list: {", ".join(remaining_categories)}.
If the user selects categories, call the get_products_by_category tool with those categories."""

        return message

    async def get_products_by_category(self, categories: list[str]) -> dict:
        """
        Get relevant product series based on one or more categories.

        Args:
            categories: List of product categories

        Returns:
            A dictionary containing success status and next_action message
        """
        try:
            self.logger.info(f"GET_PRODUCTS_BY_CATEGORY: categories={categories}")

            # Special handling for broad "Seating" category
            if len(categories) == 1 and categories[0].lower() == "seating":
                self.logger.info("GET_PRODUCTS_BY_CATEGORY: Handling broad 'Seating' category")

                seating_categories = [
                    "Benches and Ottomans",
                    "Cafe and Cafeteria Seating",
                    "Classroom Seating",
                    "Conference and Management Seating",
                    "Dining Cafeteria",
                    "Guest Seating",
                    "Heavy Duty and 24HR Office Seating",
                    "Lounge Seating",
                    "Mesh Seating",
                    "Pedestal Seating",
                    "Stacking and Nesting Chairs",
                    "Stools",
                    "Tandem Seating",
                    "Wood Frame Seating",
                    "Work and Task Seating",
                ]

                categories_list = "\n".join([f"{i+1}. {cat}" for i, cat in enumerate(seating_categories)])

                next_action = f"""Tell the user - We don't have a general "Seating" category, but we have these specific seating categories:

{categories_list}

Which seating categories are you interested in? (You can select one or more)

If the user selects categories, call the get_products_by_category tool with those categories."""

                return {"success": True, "next_action": next_action}

            api = get_middleware_api()
            result = await api.filter_by_category(categories)

            if not result.get("success"):
                return {
                    "success": False,
                    "next_action": self._get_alternative_categories_message(categories),
                }

            products = result["data"]

            if not products or len(products) == 0:
                return {
                    "success": False,
                    "next_action": self._get_alternative_categories_message(categories),
                }

            # Extract unique series descriptions
            unique_series = set()
            for product in products:
                series_desc = product.get("series_description")
                if series_desc:
                    unique_series.add(series_desc)

            if len(unique_series) > 0:
                series_count = len(unique_series)
                sorted_series = sorted(unique_series)
                categories_text = ", ".join(categories)

                # Show up to 10 series
                display_count = min(series_count, 10)

                if series_count > 10:
                    series_names = ", ".join(sorted_series[:display_count])
                    remaining_series = ", ".join(sorted_series[display_count:])
                    next_action = f"""Tell the user - Based on your preference, for the categories ({categories_text}), we have {series_count} product series available. Here are the first {display_count} series: {series_names}.

Which product series would you like to explore?
If you'd like to see more series options, let me know and I'll show you the rest.

If the user asks to see more series, show them the remaining list: {remaining_series}.
If the user selects a series, call the get_products_by_product_series tool."""
                else:
                    series_names = ", ".join(sorted_series)
                    next_action = f"""Tell the user - Based on your preference, for the categories ({categories_text}), we have {series_count} product series available: {series_names}.

Which product series would you like to explore?

If the user selects a series, call the get_products_by_product_series tool."""

                return {"success": True, "next_action": next_action}
            else:
                return {
                    "success": False,
                    "next_action": self._get_alternative_categories_message(categories),
                }

        except Exception as e:
            self.logger.error(f"GET_PRODUCTS_BY_CATEGORY: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "next_action": "There was an error processing your request. Please try again.",
            }

    async def get_products_by_product_series(self, product_series: str) -> dict:
        """
        Get product codes using product series.

        Args:
            product_series: The product series name

        Returns:
            A dictionary containing success status and next_action message with product codes
        """
        try:
            self.logger.info(f"GET_PRODUCTS_BY_PRODUCT_SERIES: Fetching products for series: {product_series}")

            api = get_middleware_api()
            result = await api.get_products_by_series(product_series)

            if not result.get("success"):
                return {
                    "success": False,
                    "error": f"No products found for series: {product_series}",
                    "next_action": f"Tell the user - For the given product series {product_series}, we don't have any products.",
                }

            products = result["data"]
            count = len(products)

            if count == 0:
                return {
                    "success": False,
                    "next_action": f"Tell the user - For the given product series {product_series}, we don't have any products.",
                }

            # Build response message
            next_action = f"Tell the user - For the given product series {product_series}, we have around {count} products with us.\n\n"

            # Show up to 10 products
            display_count = min(count, 10)

            if count > 10:
                next_action += f"Here are the first {display_count} product codes and their descriptions:\n"
            else:
                next_action += "Here are the product codes and their descriptions:\n"

            for i in range(display_count):
                product = products[i]
                next_action += (
                    f"Product Code: {product.get('product_code')}, Description: {product.get('description')}\n"
                )

            next_action += (
                "\nPlease let me know which product you are interested in, and I will fetch more details for you.\n"
            )
            next_action += "If the user chooses any of the product, call the get_product_details tool with the selected product code."

            self.logger.info(f"GET_PRODUCTS_BY_PRODUCT_SERIES: Found {count} products for series {product_series}")

            return {"success": True, "next_action": next_action}

        except Exception as e:
            self.logger.error(f"GET_PRODUCTS_BY_PRODUCT_SERIES: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "next_action": f"Tell the user - For the given product series {product_series}, we encountered an error. Please try again.",
            }

    async def get_product_details(self, product_code: str, store, thread_id: str) -> dict:
        """
        Get detailed information about a specific product.

        Args:
            product_code: The unique code for the product
            store: The BaseStore instance for session management
            thread_id: The thread ID for session tracking

        Returns:
            A dictionary containing success status and next_action message with product details
        """
        try:
            self.logger.info(
                f"GET_PRODUCT_DETAILS: Fetching details for product_code: {product_code}, thread_id: {thread_id}"
            )

            api = get_middleware_api()
            result = await api.get_product_details(product_code)

            if not result.get("success"):
                return {
                    "success": False,
                    "error": f"No product found for product code: {product_code}",
                    "next_action": f"Tell the user: The product with code '{product_code}' is not available with us. Please try again with a different product.",
                }

            product_data = result["data"]

            # Remove description_embedding before saving
            if "description_embedding" in product_data:
                del product_data["description_embedding"]

            # Get current session and update it with product data
            from gfg.state.store import get_session, set_session

            session = await get_session(store, thread_id)
            session["selected_product"] = product_data
            await set_session(store, thread_id, session)

            self.logger.info(f"GET_PRODUCT_DETAILS: Product {product_code} saved to session")

            # Build the response message
            next_action = "Tell the user - Here are the product details:\n"
            next_action += f"- **Product Code:** {product_data.get('product_code', 'N/A')}\n"
            next_action += f"- **Description:** {product_data.get('description', 'N/A')}\n"

            # Add base price if available
            if "base_price" in product_data:
                next_action += f"- **Base Price:** {product_data.get('base_price')}\n"

            next_action += f"- **Category:** {product_data.get('categories', 'N/A')}\n"

            # Add dimensions if available
            if "dimensions" in product_data:
                dims = product_data["dimensions"]
                next_action += "- **Dimensions:**\n"
                if "depth" in dims:
                    next_action += f"  - Depth: {dims['depth'].get('value')} {dims['depth'].get('unit')}\n"
                if "height" in dims:
                    next_action += f"  - Height: {dims['height'].get('value')} {dims['height'].get('unit')}\n"
                if "width" in dims:
                    next_action += f"  - Width: {dims['width'].get('value')} {dims['width'].get('unit')}\n"
                if "volume" in dims:
                    next_action += f"  - Volume: {dims['volume'].get('value')} {dims['volume'].get('unit')}\n"
                if "weight" in dims:
                    next_action += f"  - Weight: {dims['weight'].get('value')} {dims['weight'].get('unit')}\n"

            # Add features if available
            if "features" in product_data and product_data["features"]:
                next_action += "- **Features:**\n"
                for feature in product_data["features"]:
                    feature_code = feature.get("feature_code", "N/A")
                    feature_desc = feature.get("feature_description", "N/A")
                    next_action += f"  - Feature Code - {feature_code}, Feature Description - {feature_desc}\n"
                next_action += "\nWhich of the features you want to explore further?"
            else:
                next_action += "\nWhat else would you like to know about this product?"

            return {"success": True, "next_action": next_action}

        except Exception as e:
            self.logger.error(f"GET_PRODUCT_DETAILS: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "next_action": f"There was an error fetching product details for '{product_code}'. Please try again.",
            }

    async def get_options_for_feature(self, product_code: str, feature_code: str, store, thread_id: str) -> dict:
        """
        Get available options for a specific top-level feature of a product.

        Args:
            product_code: The unique code for the product
            feature_code: The unique identifier for the feature
            store: The BaseStore instance for session management
            thread_id: The thread ID for session tracking

        Returns:
            A dictionary containing success status and next_action message with feature options
        """
        try:
            self.logger.info(
                f"GET_OPTIONS_FOR_FEATURE: product_code={product_code}, feature_code={feature_code}, thread_id={thread_id}"
            )

            # Get selected product from session
            from gfg.state.store import get_session

            session = await get_session(store, thread_id)
            product = session.get("selected_product")

            # Find the feature in the product data
            feature = None
            if product and "features" in product:
                for f in product["features"]:
                    if f.get("feature_code") == feature_code:
                        feature = f
                        break

            # Build options summary
            options_summary = {
                "feature_code": feature.get("feature_code"),
                "feature_description": feature.get("feature_description"),
                "options": [],
            }

            for opt in feature.get("options", []):
                options_summary["options"].append(
                    {
                        "option_code": opt.get("option_code"),
                        "option_description": opt.get("option_description"),
                        "option_price": opt.get("option_price"),
                        "has_nested_feature": bool(opt.get("nested_feature")),
                    }
                )

            # Create detailed, readable list of options
            options_list_text = []
            for o in options_summary["options"]:
                option_text = f"- **Description:** {o['option_description']} (Code: {o['option_code']})\n"
                option_text += f"  - **Price:** CA${o['option_price']:.2f}\n"
                option_text += f"  - **Further Details Available:** {'Yes' if o['has_nested_feature'] else 'No'}"
                options_list_text.append(option_text)

            options_list_formatted = "\n\n".join(options_list_text)

            has_nested_features = any(o["has_nested_feature"] for o in options_summary["options"])

            if has_nested_features:
                final_guidance = "Which option would you like to explore in more detail?"
            else:
                final_guidance = "These are the final choices for this feature. We can now go back to explore other features of the product."

            next_action = f"Here is the detailed information for the feature '{feature.get('feature_description')}' (Code: {feature.get('feature_code')}):\n\n"
            next_action += f"Below are the available options for this feature:\n\n{options_list_formatted}\n\n"
            next_action += f'**Agent Instruction:** If the user asks a direct question, answer only that specific question using the data above. Otherwise, guide the user by asking: "{final_guidance}"'

            return {"success": True, "next_action": next_action}

        except Exception as e:
            self.logger.error(f"GET_OPTIONS_FOR_FEATURE: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "next_action": "There was an error fetching feature options. Please try again.",
            }

    async def get_configuration_options(self, product_code: str, navigation_path: list, store, thread_id: str) -> dict:
        """
        Navigate deeper into a product's nested features.

        Args:
            product_code: The unique code for the product
            navigation_path: Ordered list of feature_code and option_code selections
            store: The BaseStore instance for session management
            thread_id: The thread ID for session tracking

        Returns:
            A dictionary containing success status and next_action message
        """
        try:
            self.logger.info(
                f"GET_CONFIGURATION_OPTIONS: Navigating product {product_code} with path: {navigation_path}"
            )

            # Get session to access selected product
            from gfg.state.store import get_session

            session = await get_session(store, thread_id)
            selected_product = session.get("selected_product")

            # Validate selected_product exists
            if not selected_product:
                self.logger.error("GET_CONFIGURATION_OPTIONS: No product found in session")
                return {
                    "success": False,
                    "error": "No product found in session",
                    "next_action": "Please use the get_product_details tool first to fetch product information.",
                }

            product_data = selected_product

            # Traverse the nested structure
            current_level = {"features": product_data.get("features", [])}
            last_selection_description = "your previous selection"

            # Loop through the provided path to find the current level
            for step in navigation_path:
                feature_code = step.get("feature_code")
                option_code = step.get("option_code")

                # Find the feature at this level
                feature = None
                for f in current_level.get("features", []):
                    if f.get("feature_code") == feature_code:
                        feature = f
                        break

                if not feature:
                    self.logger.error(f"GET_CONFIGURATION_OPTIONS: Feature {feature_code} not found at current level")
                    return {
                        "success": False,
                        "error": f"Feature {feature_code} not found",
                        "next_action": f"Feature code '{feature_code}' not found in the navigation path.",
                    }

                # Find the option within this feature
                option = None
                for o in feature.get("options", []):
                    if o.get("option_code") == option_code:
                        option = o
                        break

                if not option:
                    self.logger.error(
                        f"GET_CONFIGURATION_OPTIONS: Option {option_code} not found in feature {feature_code}"
                    )
                    return {
                        "success": False,
                        "error": f"Option {option_code} not found",
                        "next_action": f"Option code '{option_code}' not found in feature '{feature_code}'.",
                    }

                # Check if the path terminates at this option (no more nested features)
                if not option.get("nested_feature"):
                    return {
                        "success": True,
                        "next_action": f"You have selected '{option.get('option_description')}' option. This is the final choice for this path. We can now go back to explore other features or options.",
                    }

                # Move one level deeper into the nested structure
                current_level = {"features": [option.get("nested_feature")]}
                last_selection_description = f"'{option.get('option_description')}'"

            # At the target level, get the details of the next feature
            target_feature = current_level.get("features", [])[0]

            # Build options summary
            options_summary = []
            has_nested_features = False

            for opt in target_feature.get("options", []):
                option_info = {
                    "option_code": opt.get("option_code"),
                    "option_description": opt.get("option_description"),
                    "option_price": opt.get("option_price", 0),
                    "has_nested_feature": bool(opt.get("nested_feature")),
                }
                options_summary.append(option_info)
                if option_info["has_nested_feature"]:
                    has_nested_features = True

            # Create detailed, readable list of options
            options_list_text = []
            for o in options_summary:
                price = float(o["option_price"])
                option_text = f"- **Description:** {o['option_description']} (Code: {o['option_code']})\n"
                option_text += f"  - **Price:** CA${price:.2f}\n"
                option_text += f"  - **Further Details Available:** {'Yes' if o['has_nested_feature'] else 'No'}"
                options_list_text.append(option_text)

            options_formatted = "\n\n".join(options_list_text)

            # Determine final guidance
            if has_nested_features:
                final_guidance = "Which of these options would you like to explore in more detail?"
            else:
                final_guidance = "These are the final choices for this feature. We can now go back to explore other features or options."

            # Build next_action message
            next_action = f"After selecting {last_selection_description} option, you can now explore '{target_feature.get('feature_description')}' (Code: {target_feature.get('feature_code')}) feature.\n\n"
            next_action += "Below are the available options for this feature:\n\n"
            next_action += options_formatted
            next_action += f'\n\n**Agent Instruction:** If the user asks a direct question, answer only that specific question using the data above. Otherwise, guide the user by asking: "{final_guidance}"'

            self.logger.info(
                f"GET_CONFIGURATION_OPTIONS: Successfully navigated to {target_feature.get('feature_code')} with {len(options_summary)} options"
            )

            return {"success": True, "next_action": next_action}

        except Exception as e:
            self.logger.error(f"GET_CONFIGURATION_OPTIONS: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Error navigating configuration options: {str(e)}",
                "next_action": "There was an issue navigating the configuration options. Please try again.",
            }

    async def get_product_series_by_fabric(self, fabric_code: str) -> dict:
        """
        Get product series associated with a specific fabric code.

        Args:
            fabric_code: The code for the fabric

        Returns:
            A dictionary containing success status and next_action message
        """
        try:
            self.logger.info(f"GET_PRODUCT_SERIES_BY_FABRIC: Fetching product series for fabric code: {fabric_code}")

            # Default fallback message
            fallback_next_action = (
                f"Tell the user that there are no product available for the given fabric code '{fabric_code}'"
            )

            api = get_middleware_api()

            # STEP 1: Get family_code from fabric_code
            result_family = await api.get_family_code_by_fabric(fabric_code)

            if not result_family.get("success"):
                self.logger.warning(f"GET_PRODUCT_SERIES_BY_FABRIC: No family code found for fabric: {fabric_code}")
                return {"success": False, "next_action": fallback_next_action}

            family_data = result_family["data"]

            if not family_data or len(family_data) == 0:
                self.logger.warning("GET_PRODUCT_SERIES_BY_FABRIC: Empty family code data")
                return {"success": False, "next_action": fallback_next_action}

            family_code = family_data[0].get("family_code")

            if not family_code:
                self.logger.warning("GET_PRODUCT_SERIES_BY_FABRIC: No family_code in response")
                return {"success": False, "next_action": fallback_next_action}

            self.logger.info(f"GET_PRODUCT_SERIES_BY_FABRIC: Found family_code: {family_code}")

            # STEP 2: Get chair series using family_code
            result_chair = await api.get_chair_series_by_family_code(family_code)

            if not result_chair.get("success"):
                self.logger.warning(f"GET_PRODUCT_SERIES_BY_FABRIC: No chair series found for family: {family_code}")
                return {"success": False, "next_action": fallback_next_action}

            chair_data = result_chair["data"]

            if not chair_data or len(chair_data) == 0:
                self.logger.warning("GET_PRODUCT_SERIES_BY_FABRIC: Empty chair series data")
                return {"success": False, "next_action": fallback_next_action}

            # Extract unique series codes from chair data
            chair_series = [item.get("chair_series") for item in chair_data if item.get("chair_series")]
            unique_chair_series = list(set(chair_series))  # Remove duplicates

            if len(unique_chair_series) == 0:
                self.logger.warning("GET_PRODUCT_SERIES_BY_FABRIC: No series codes found in chair data")
                return {"success": False, "next_action": fallback_next_action}

            self.logger.info(f"GET_PRODUCT_SERIES_BY_FABRIC: Found {len(unique_chair_series)} unique chair series")

            # STEP 3: Get product series using chair series codes
            result_series = await api.get_product_series_by_series_list(unique_chair_series)

            if not result_series.get("success"):
                self.logger.warning("GET_PRODUCT_SERIES_BY_FABRIC: No product series found")
                return {"success": False, "next_action": fallback_next_action}

            series_data = result_series["data"]

            if not series_data or len(series_data) == 0:
                self.logger.warning("GET_PRODUCT_SERIES_BY_FABRIC: Empty product series data")
                return {"success": False, "next_action": fallback_next_action}

            # Extract unique series descriptions
            series_descriptions = [
                item.get("series_description") for item in series_data if item.get("series_description")
            ]
            unique_series = list(set(series_descriptions))  # Remove duplicates
            unique_series.sort()  # Sort alphabetically

            if len(unique_series) == 0:
                return {"success": False, "next_action": fallback_next_action}

            unique_series_count = len(unique_series)

            # Show up to 10 series
            display_count = min(unique_series_count, 10)

            if unique_series_count > 10:
                series_names_string = ", ".join(unique_series[:display_count])
                next_action = f"Tell the user for the given fabric code {fabric_code}, there are {unique_series_count} product series available. Here are the first {display_count} series names: {series_names_string}. If you want to explore products under any of these product series, let me know.\n\nIf the user provides any series name, call the get_products_by_product_series tool."
            else:
                series_names_string = ", ".join(unique_series)
                next_action = f"Tell the user for the given fabric code {fabric_code}, there are {unique_series_count} product series available. Here are the series names: {series_names_string}. If you want to explore products under any of these product series, let me know.\n\nIf the user provides any series name, call the get_products_by_product_series tool."

            self.logger.info(
                f"GET_PRODUCT_SERIES_BY_FABRIC: Successfully found {unique_series_count} unique product series"
            )

            return {"success": True, "next_action": next_action}

        except Exception as e:
            self.logger.error(f"GET_PRODUCT_SERIES_BY_FABRIC: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Error fetching product series: {str(e)}",
                "next_action": f"Tell the user that there are no product available for the given fabric code '{fabric_code}'",
            }

    async def get_available_categories(self) -> dict:
        """
        Get available product categories.
        Shows first 12 categories initially, with option to see more.

        Returns:
            A dictionary containing success status and next_action message with available categories
        """
        try:
            self.logger.info("GET_AVAILABLE_CATEGORIES: Fetching all available categories")

            # Show first 12 categories initially
            initial_categories = ALL_PRODUCT_CATEGORIES[:12]
            remaining_categories = ALL_PRODUCT_CATEGORIES[12:]

            categories_list = "\n".join([f"{i+1}. {cat}" for i, cat in enumerate(initial_categories)])

            next_action = f"""Tell the user - We have the following categories available:

{categories_list}

Which categories are you interested in? (You can select one or more)
If you'd like to see more category options, let me know and I'll show you the rest.

If the user asks to see more categories, show them the remaining list: {", ".join(remaining_categories)}.
If the user selects categories, call the get_products_by_category tool with those categories."""

            self.logger.info(f"GET_AVAILABLE_CATEGORIES: Successfully returned {len(initial_categories)} of {len(ALL_PRODUCT_CATEGORIES)} categories")

            return {"success": True, "next_action": next_action}

        except Exception as e:
            self.logger.error(f"GET_AVAILABLE_CATEGORIES: Unexpected error - {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": f"Error fetching categories: {str(e)}",
                "next_action": "There was an error fetching available categories. Please try again.",
            }


# Global singleton instance
_product_suggestion_service = None


def get_product_suggestion_service() -> ProductSuggestionService:
    """Get or create the global product suggestion service instance."""
    global _product_suggestion_service
    if _product_suggestion_service is None:
        _product_suggestion_service = ProductSuggestionService()
    return _product_suggestion_service
