import os

from langchain.agents import create_agent
from langchain_openai import ChatOpenAI

from gfg.prompts.product_suggestion_prompt import PRODUCT_SUGGESTION_SYSTEM_PROMPT
from gfg.tools.handoff_tools import transfer_to_category_discovery_agent, transfer_to_faq_agent
from gfg.tools.product_suggestion_tools import (
    get_available_categories,
    get_configuration_options,
    get_options_for_feature,
    get_product_details,
    get_product_series_by_fabric,
    get_products_by_category,
    get_products_by_product_series,
)
from gfg.utils.logger import get_logger

logger = get_logger(__name__)


# Initialize LLM for Product Suggestion Agent
product_suggestion_llm = ChatOpenAI(
    model=os.getenv("OPENAI_MODEL_PRODUCT_SUGGESTION", "gpt-5.1"),
    temperature=float(os.getenv("OPENAI_TEMPERATURE_PRODUCT_SUGGESTION", 0.2)),
)


def create_product_suggestion_agent(checkpointer=None, store=None):
    """
    Create the Product Suggestion Agent with product tools and handoff capability.

    Args:
        checkpointer: Optional checkpointer for conversation memory
        store: Optional store for session data

    Returns:
        Compiled Product Suggestion Agent graph
    """
    # Create Product Suggestion Agent with all product tools and handoff tools
    agent = create_agent(
        model=product_suggestion_llm,
        tools=[
            transfer_to_faq_agent,
            transfer_to_category_discovery_agent,
            get_available_categories,
            get_products_by_category,
            get_products_by_product_series,
            get_product_series_by_fabric,
            get_product_details,
            get_options_for_feature,
            get_configuration_options,
        ],
        system_prompt=PRODUCT_SUGGESTION_SYSTEM_PROMPT,
        name="ProductSuggestionAgent",
        checkpointer=checkpointer,
        store=store,
    )

    logger.info("Product Suggestion Agent created successfully")
    return agent
