import os

from langchain.agents import create_agent
from langchain_openai import ChatOpenAI

from gfg.prompts.faq_prompt import FAQ_SYSTEM_PROMPT
from gfg.tools.handoff_tools import transfer_to_category_discovery_agent
from gfg.utils.logger import get_logger

logger = get_logger(__name__)


# Initialize LLM for FAQ Agent
faq_llm = ChatOpenAI(
    model=os.getenv("OPENAI_MODEL_FAQ", "gpt-4.1-mini"),  # Could use gpt-3.5-turbo for cost savings
    temperature=float(os.getenv("OPENAI_TEMPERATURE_FAQ", 0.3)),  # Slightly higher for more natural FAQ responses
)


def create_faq_agent(checkpointer=None, store=None):
    """
    Create the FAQ Agent with handoff capability.

    Args:
        checkpointer: Optional checkpointer for conversation memory
        store: Optional store for session data

    Returns:
        Compiled FAQ agent graph
    """
    # Create FAQ agent with RAG search and handoff tools
    agent = create_agent(
        model=faq_llm,
        tools=[
            transfer_to_category_discovery_agent,  # Can hand off to category discovery agent
        ],
        system_prompt=FAQ_SYSTEM_PROMPT,
        name="FAQAgent",
        checkpointer=checkpointer,
        store=store,
    )

    logger.info("FAQ Agent created successfully")
    return agent
