import os

from langchain.agents import create_agent
from langchain_openai import ChatOpenAI

from gfg.prompts.category_discovery_prompt import CATEGORY_DISCOVERY_SYSTEM_PROMPT
from gfg.tools.category_discovery_tools import get_decision_domains, get_decision_product_families, get_decision_step
from gfg.tools.handoff_tools import transfer_to_faq_agent, transfer_to_product_suggestion_agent
from gfg.utils.logger import get_logger

logger = get_logger(__name__)


# Initialize LLM for Category Discovery Agent
category_discovery_llm = ChatOpenAI(
    model=os.getenv("OPENAI_MODEL_CATEGORY_DISCOVERY", "gpt-5.1"),
    temperature=float(os.getenv("OPENAI_TEMPERATURE_CATEGORY_DISCOVERY", 0.2)),
)


def create_category_discovery_agent(checkpointer=None, store=None):
    """
    Create the Category Discovery Agent with decision tree navigation tools.

    Args:
        checkpointer: Optional checkpointer for conversation memory
        store: Optional store for session data

    Returns:
        Compiled Category Discovery Agent graph
    """
    # Create Category Discovery Agent with all tools
    agent = create_agent(
        model=category_discovery_llm,
        tools=[
            get_decision_domains,
            get_decision_product_families,
            get_decision_step,
            transfer_to_faq_agent,
            transfer_to_product_suggestion_agent,
        ],
        system_prompt=CATEGORY_DISCOVERY_SYSTEM_PROMPT,
        name="CategoryDiscoveryAgent",
        checkpointer=checkpointer,
        store=store,
    )

    logger.info("Category Discovery Agent created successfully with decision tree tools")
    return agent
