import json
import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from pydantic import BaseModel

from gfg.gfg_agent import get_gfg_agent, initialize_gfg_agent, reset_gfg_agent
from gfg.services.langfuse_service import langfuse_service
from gfg.services.postgres_db_service import PostgresDBService
from gfg.state.checkpointer import get_checkpointer, get_pool
from gfg.utils.logger import get_logger

logger = get_logger(__name__)

# Global DB service for conversation history
db_service = PostgresDBService()

# CORS allowlist from environment (comma-separated). Fail fast if missing.
_cors_origins_env = os.getenv("CORS_ALLOWED_ORIGINS", "").strip()
if not _cors_origins_env:
    raise RuntimeError("CORS_ALLOWED_ORIGINS environment variable is required")

ALLOWED_ORIGINS = [origin.strip() for origin in _cors_origins_env.split(",") if origin.strip()]
if not ALLOWED_ORIGINS:
    raise RuntimeError("CORS_ALLOWED_ORIGINS must contain at least one origin")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle - startup and shutdown."""
    # === STARTUP LOGIC ===
    logger.info("Starting up GFG Agent API...")

    # Initialize Langfuse service (checks LANGFUSE_ENABLED internally)
    try:
        langfuse_service.initialize()
    except Exception as e:
        logger.error(f"Failed to initialize Langfuse service: {e}")

    # Initialize PostgreSQL checkpointer
    checkpointer_ready = False
    checkpointer = get_checkpointer()
    if checkpointer:
        try:
            # Explicitly open the pool with timeout before setup
            pool = get_pool()
            if pool:
                await pool.open(wait=True, timeout=30)
                logger.info("PostgreSQL connection pool opened")
            await checkpointer.setup()
            logger.info("Async PostgreSQL checkpointer initialized")
            checkpointer_ready = True
        except Exception as e:
            logger.error(f"Failed to initialize checkpointer: {e}")
            logger.warning("Will use in-memory checkpointer as fallback")

    # Initialize GFG agent AFTER checkpointer setup
    # Critical: Agent must be initialized for the app to serve requests
    # Use memory checkpointer if PostgreSQL checkpointer setup failed
    use_memory_fallback = not checkpointer_ready
    try:
        if use_memory_fallback:
            logger.warning("Initializing GFG Agent with in-memory checkpointer (PostgreSQL unavailable)")
        initialize_gfg_agent(use_memory_checkpointer=use_memory_fallback)
        logger.info("GFG Agent initialized successfully")
        if use_memory_fallback:
            logger.warning("Conversation history will NOT be persisted across restarts.")
    except Exception as e:
        logger.error(f"Failed to initialize GFG Agent: {e}")
        if not use_memory_fallback:
            # Only try fallback if we weren't already using memory checkpointer
            logger.warning("Attempting fallback to in-memory checkpointer...")
            try:
                # Reset agent state to ensure clean re-initialization
                reset_gfg_agent()
                initialize_gfg_agent(use_memory_checkpointer=True)
                logger.warning(
                    "GFG Agent initialized with in-memory checkpointer (fallback mode). "
                    "Conversation history will NOT be persisted across restarts."
                )
            except Exception as fallback_error:
                logger.critical(f"Failed to initialize GFG Agent even with fallback: {fallback_error}")
                raise RuntimeError(
                    "Critical: GFG Agent initialization failed. Cannot start application."
                ) from fallback_error
        else:
            # Already tried memory checkpointer and it failed
            logger.critical(f"Failed to initialize GFG Agent with in-memory checkpointer: {e}")
            raise RuntimeError("Critical: GFG Agent initialization failed. Cannot start application.") from e

    # Initialize conversation history database service
    try:
        await db_service.initialize()
        logger.info("Conversation history database service initialized")
    except Exception as e:
        logger.error(f"Failed to initialize conversation history service: {e}")

    # === YIELD TO RUN THE APP ===
    yield

    # === SHUTDOWN LOGIC ===
    logger.info("Shutting down GFG Agent API...")

    # Flush Langfuse traces (no-op if disabled)
    try:
        langfuse_service.flush()
    except Exception as e:
        logger.error(f"Error flushing Langfuse: {e}")

    # Close database service
    try:
        await db_service.close()
        logger.info("Database service closed")
    except Exception as e:
        logger.error(f"Error closing database service: {e}")

    # Close checkpointer pool
    pool = get_pool()
    if pool:
        try:
            await pool.close()
            logger.info("Checkpointer connection pool closed")
        except Exception as e:
            logger.error(f"Error closing checkpointer pool: {e}")


app = FastAPI(
    title="GFG Agent API",
    description="GFG Agent with Subcategory Discovery and FAQ Support (Swarm Architecture)",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS setup to allow frontend domain to call the API (including preflight)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    """Health check endpoint."""
    return {"status": "ok"}


ROLE_TO_TYPE = {
    "user": "human",
    "assistant": "ai",
    "system": "system",
    "tool": "tool",
}


def _to_text_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text" and isinstance(block.get("text"), str):
                    parts.append(block["text"])
        return " ".join(parts)
    return str(content)


def _to_lc_message(msg: dict[str, Any]) -> BaseMessage:
    msg_type = msg.get("type") or ROLE_TO_TYPE.get(str(msg.get("role", "")).lower())
    content = _to_text_content(msg.get("content"))
    if msg_type == "human":
        return HumanMessage(content=content)
    if msg_type == "ai":
        return AIMessage(content=content)
    if msg_type == "system":
        return SystemMessage(content=content)
    if msg_type == "tool":
        return ToolMessage(content=content, tool_call_id=msg.get("tool_call_id", ""))
    return HumanMessage(content=content)


def normalize_input(payload: dict[str, Any]) -> dict[str, Any]:
    data = payload or {}
    if "input" in data:
        inner = data["input"]
        if isinstance(inner, str):
            return {"messages": [HumanMessage(content=inner)]}
        if isinstance(inner, dict):
            if "messages" in inner and isinstance(inner["messages"], list):
                lc_messages = [_to_lc_message(m) for m in inner["messages"]]
                return {"messages": lc_messages}
            if "content" in inner:
                return {"messages": [_to_lc_message(inner)]}
            return inner
    if "messages" in data and isinstance(data["messages"], list):
        lc_messages = [_to_lc_message(m) for m in data["messages"]]
        return {"messages": lc_messages}
    return {"messages": [HumanMessage(content=str(data))]}


# Pydantic model for chat endpoint
class ChatMessage(BaseModel):
    role: str
    content: list[dict[str, Any]]


class ChatInput(BaseModel):
    messages: list[ChatMessage]
    caller_number: str | None = None  # Phone number of the caller


class StreamRequest(BaseModel):
    input: ChatInput
    thread_id: str | None = None


@app.post("/chat/stream")
async def chat_stream(request: StreamRequest):
    """GFG Agent endpoint - routes to Subcategory Discovery and FAQ agents."""
    try:
        normalized_input = normalize_input(request.input.model_dump())

        user_message_content = ""
        if normalized_input.get("messages"):
            last_message = normalized_input["messages"][-1]
            if isinstance(last_message, HumanMessage):
                user_message_content = last_message.content

        # Generate thread_id if not provided
        if not request.thread_id or not request.thread_id.strip():
            conversation_id = f"gfg-thread-{uuid.uuid4()}"
        else:
            conversation_id = request.thread_id

        caller_number = request.input.caller_number
        if caller_number:
            logger.info(f"Request from caller: {caller_number}, thread: {conversation_id}")

        if user_message_content and conversation_id:
            await db_service.append_conversation_message(
                conversation_id=conversation_id,
                role="user",
                content=user_message_content,
                agent_name="GFGAgent",
            )

        config = {"configurable": {"thread_id": conversation_id}}
        if caller_number:
            config["configurable"]["caller_number"] = caller_number

        # Add Langfuse handler (returns None if disabled)
        langfuse_handler = langfuse_service.get_handler()
        if langfuse_handler:
            config["callbacks"] = [langfuse_handler]

        async def generate_stream():
            assistant_response = ""
            try:
                agent = get_gfg_agent()
                async for event in agent.astream_events(normalized_input, config=config, version="v2"):
                    event_type = event.get("event")
                    event_data = event.get("data", {})
                    event_name = event.get("name", "")

                    if event_type == "on_chat_model_stream":
                        chunk = event_data.get("chunk")
                        if chunk and hasattr(chunk, "content") and chunk.content:
                            text_content = _to_text_content(chunk.content)
                            assistant_response += text_content
                            token_data = {
                                "thread_id": conversation_id,
                                "type": "token",
                                "content": text_content,
                                "timestamp": time.time(),
                            }
                            yield f"data: {json.dumps(token_data)}\n\n"

                    elif event_type == "on_custom_event":
                        if event_name == "say_message" and isinstance(event_data, dict):
                            say_message = event_data.get("message", "")
                            tool_name = event_data.get("tool", "")
                            say_data = {
                                "thread_id": conversation_id,
                                "type": "say",
                                "message": say_message,
                                "tool": tool_name,
                                "timestamp": time.time(),
                            }
                            yield f"data: {json.dumps(say_data)}\n\n"

                if assistant_response and conversation_id:
                    await db_service.append_conversation_message(
                        conversation_id=conversation_id,
                        role="assistant",
                        content=assistant_response,
                        agent_name="GFGAgent",
                    )

                yield f"data: {json.dumps({'thread_id': conversation_id, 'type': 'end_of_response', 'content': 'end of response', 'timestamp': time.time()})}\n\n"

            except Exception as e:
                import traceback

                logger.error(f"Error in streaming: {traceback.format_exc()}")
                error_data = {"error": str(e), "type": type(e).__name__}
                yield f"data: {json.dumps(error_data)}\n\n"

        return StreamingResponse(
            generate_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Content-Type": "text/event-stream; charset=utf-8",
            },
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e
