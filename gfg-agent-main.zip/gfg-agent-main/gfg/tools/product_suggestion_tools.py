from langchain_core.tools import tool
from langgraph.config import get_config

from gfg.services.product_suggestion_service import get_product_suggestion_service
from gfg.utils.logger import get_logger

logger = get_logger(__name__)


@tool("GetProductsByCategory")
async def get_products_by_category(categories: list[str]) -> dict:
    """
    Use this tool to get available product series for one or more categories.

    Args:
        categories: List of product categories (e.g., ["Seating"], ["Stools", "Tandem Seating"], etc.)

    Returns:
        A dictionary containing success status and next_action message with available product series
    """
    service = get_product_suggestion_service()
    return await service.get_products_by_category(categories)


@tool("GetProductsByProductSeries")
async def get_products_by_product_series(product_series: str) -> dict:
    """
    Get product codes using product series.

    Args:
        product_series: Get product series name from either the output of get_products_by_category tool or get_products_by_fabric tool.

    Returns:
        A dictionary containing success status and next_action message with product codes
    """
    service = get_product_suggestion_service()
    return await service.get_products_by_product_series(product_series)


@tool("GetProductDetails")
async def get_product_details(product_code: str) -> dict:
    """
    Use this tool to get detailed information about a specific product using its product code.

    Args:
        product_code: The unique code for the product. Always ask the user for this information or retrieve it from the conversation context.

    Returns:
        A dictionary containing success status and next_action message with product details
    """
    config = get_config()
    thread_id = config.get("configurable", {}).get("thread_id")

    from gfg.state.store import get_store

    store = get_store()

    service = get_product_suggestion_service()
    return await service.get_product_details(product_code, store, thread_id)


@tool("GetOptionsForFeature")
async def get_options_for_feature(product_code: str, feature_code: str) -> dict:
    """
    Use this tool to get the available options for a specific top-level feature of a product after the initial details have been fetched using the get_product_details tool.

    Args:
        product_code: The unique code for the product. Always ask the user for this information or retrieve it from the conversation context.
        feature_code: The unique identifier for the feature the user wants to explore. IMPORTANT: Even if the user refers to the feature by its descriptive name, you MUST use the corresponding feature_code from the output of get_product_details tool.

    Returns:
        A dictionary containing success status and next_action message with feature options
    """
    config = get_config()
    thread_id = config.get("configurable", {}).get("thread_id")

    from gfg.state.store import get_store

    store = get_store()

    service = get_product_suggestion_service()
    return await service.get_options_for_feature(product_code, feature_code, store, thread_id)


@tool("GetConfigurationOptions")
async def get_configuration_options(product_code: str, navigation_path: list) -> dict:
    """
    Use this powerful tool to navigate deeper into a product's features. It should be used whenever a user selects an option that has 'Further Details Available: Yes' (or has_nested_feature: true).
    Args:
        product_code: The unique code for the product. Always ask the user for this information or retrieve it from the conversation context.
        navigation_path: An ordered list of objects representing the user's selections so far. Each object must contain the `feature_code` and the chosen `option_code` for that step. This path is used to traverse the nested data structure. Example: [{'feature_code': '1004-01', 'option_code': 'NS'}, {'feature_code': '1004-NS-10-04', 'option_code': '1004'}]
    Returns:
        A dictionary containing success status and next_action message
    """
    config = get_config()
    thread_id = config.get("configurable", {}).get("thread_id")

    from gfg.state.store import get_store

    store = get_store()

    service = get_product_suggestion_service()
    return await service.get_configuration_options(product_code, navigation_path, store, thread_id)


@tool("GetProductSeriesByFabric")
async def get_product_series_by_fabric(fabric_code: str) -> dict:
    """
    Use this tool to get product series associated with a specific fabric code.

    Args:
        fabric_code: The code for the fabric. Always ask the user for this information.

    Returns:
        A dictionary containing success status and next_action message
    """
    service = get_product_suggestion_service()
    return await service.get_product_series_by_fabric(fabric_code)


@tool("GetAvailableCategories")
async def get_available_categories() -> dict:
    """
    Use this tool to get all available product categories.
    Call this when the user is asking about products but hasn't specified a category yet.
    
    Returns:
        A dictionary containing success status and next_action message with all available categories
    """
    service = get_product_suggestion_service()
    return await service.get_available_categories()
