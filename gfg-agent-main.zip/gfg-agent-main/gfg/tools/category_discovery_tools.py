from langchain_core.tools import tool

from gfg.services.category_discovery_service import get_category_discovery_service
from gfg.utils.logger import get_logger

logger = get_logger(__name__)


@tool("GetDecisionDomains")
async def get_decision_domains() -> dict:
    """
    Use this tool at the start of the conversation to get the available furniture domains.
    This should be the first tool called to help users identify if they need furniture for Workplace, Education, or Healthcare settings.

    Returns:
        A dictionary containing success status, list of domains, and next_action message
    """
    service = get_category_discovery_service()
    return await service.get_decision_domains()


@tool("GetDecisionProductFamilies")
async def get_decision_product_families(domain: str) -> dict:
    """
    Use this tool once the user has identified their domain (Workplace, Education, or Healthcare) to get the available product families for that domain.

    Args:
        domain: The domain selected by the user. Must be one of: "Workplace", "Education", or "Healthcare"

    Returns:
        A dictionary containing success status, list of product families, and next_action message
    """
    service = get_category_discovery_service()
    return await service.get_decision_product_families(domain)


@tool("GetDecisionStep")
async def get_decision_step(domain: str, product_family: str, navigation_path: list[str]) -> dict:
    """
    Use this powerful tool to navigate through the furniture decision tree. This is the main tool for category discovery.

    How to use this tool:
    1. First call: Pass domain, product_family, and an empty navigation_path [] to get the first question
    2. After user answers: Add the "next" node ID from their chosen option to navigation_path and call again

    Args:
        domain: The domain (Workplace, Education, or Healthcare)
        product_family: The product family (e.g., "Desking + Tables", "Seating", "Storage")
        navigation_path: List of node IDs representing the path taken. Start with empty list [], then append the "next" value from each selected option.
                        Example progression: [] -> ["1"] -> ["1", "1A"] -> ["1", "1A", "Result-1A-1"]
    """
    service = get_category_discovery_service()
    return await service.get_decision_step(domain, product_family, navigation_path)
