from langgraph_swarm import create_handoff_tool

from gfg.utils.logger import get_logger

logger = get_logger(__name__)

transfer_to_faq_agent = create_handoff_tool(
    agent_name="FAQAgent",
    description="Transfer to FAQAgent for FAQ questions, complaints, customer service issues.",
)

transfer_to_category_discovery_agent = create_handoff_tool(
    agent_name="CategoryDiscoveryAgent",
    description="Transfer to CategoryDiscoveryAgent for category discovery.",
)

transfer_to_product_suggestion_agent = create_handoff_tool(
    agent_name="ProductSuggestionAgent",
    description="Transfer to ProductSuggestionAgent for product search, product details, product configuration, and all product-related queries.",
)
