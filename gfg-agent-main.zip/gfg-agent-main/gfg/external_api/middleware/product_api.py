"""
Middleware Product API Client
Handles all API calls to the GFG middleware service
"""

import os
from typing import Any

import httpx

from gfg.utils.logger import get_logger

logger = get_logger(__name__)


class MiddlewareProductAPI:
    """Client for GFG Middleware Product APIs"""

    def __init__(self):
        self.base_url = os.getenv("MIDDLEWARE_API_BASE_URL", "http://localhost:8001")
        self.timeout = 30.0

    async def get_product_details(self, product_code: str) -> dict[str, Any]:
        """
        Get detailed information for a specific product.

        Args:
            product_code: The unique product code

        Returns:
            Dict containing product details or error information
        """
        try:
            api_url = f"{self.base_url}/middleware/api/v1/products/product-details"
            params = {"product_code": product_code}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, params=params)

                if response.status_code == 404:
                    return {"error": "not_found", "detail": f"No product found for product code: {product_code}"}

                if response.status_code == 200:
                    data = response.json()
                    if "detail" in data:
                        return {"error": "not_found", "detail": data["detail"]}
                    return {"success": True, "data": data}

                return {"error": "api_error", "status_code": response.status_code}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}

    async def get_products_by_series(self, series_description: str) -> dict[str, Any]:
        """
        Get product codes for a specific product series.

        Args:
            series_description: The series description/name

        Returns:
            Dict containing list of products or error information
        """
        try:
            api_url = f"{self.base_url}/middleware/api/v1/products/product-codes"
            params = {"series_description": series_description}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, params=params)

                if response.status_code == 404:
                    return {"error": "not_found", "detail": f"No products found for series: {series_description}"}

                if response.status_code == 200:
                    data = response.json()
                    if "detail" in data:
                        return {"error": "not_found", "detail": data["detail"]}
                    return {"success": True, "data": data}

                return {"error": "api_error", "status_code": response.status_code}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}

    async def filter_by_category_and_subcategory(self, category: str, subcategory: str) -> dict[str, Any]:
        """
        Filter products by category and subcategory.

        Args:
            category: Product category
            subcategory: Product subcategory

        Returns:
            Dict containing list of products or error information
        """
        try:
            api_url = f"{self.base_url}/middleware/api/v1/products/filter-by-category-subcategory"
            params = {"category": category, "subcategory": subcategory}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, params=params)

                if response.status_code == 404:
                    return {"error": "not_found", "detail": "No products found"}

                if response.status_code == 200:
                    data = response.json()
                    if "detail" in data:
                        return {"error": "not_found", "detail": data["detail"]}
                    return {"success": True, "data": data}

                return {"error": "api_error", "status_code": response.status_code}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}

    async def filter_by_category(self, categories: list[str]) -> dict[str, Any]:
        """
        Filter products by one or more categories.

        Args:
            categories: List of product categories

        Returns:
            Dict containing list of products or error information
        """
        try:
            api_url = f"{self.base_url}/middleware/api/v1/products/filter-by-category"
            # Build params with multiple category parameters
            params = [("category", cat) for cat in categories]

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, params=params)

                if response.status_code == 404:
                    return {"error": "not_found", "detail": "No products found"}

                if response.status_code == 200:
                    data = response.json()
                    if "detail" in data:
                        return {"error": "not_found", "detail": data["detail"]}
                    return {"success": True, "data": data}

                return {"error": "api_error", "status_code": response.status_code}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}

    async def get_family_code_by_fabric(self, fabric_code: str) -> dict[str, Any]:
        """
        Get family code for a specific fabric code.

        Args:
            fabric_code: The fabric code

        Returns:
            Dict containing family code or error information
        """
        try:
            api_url = f"{self.base_url}/middleware/api/v1/products/family-code"
            params = {"fabric_code": fabric_code}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, params=params)

                if response.status_code == 404:
                    return {"error": "not_found", "detail": "No family code found"}

                if response.status_code == 200:
                    data = response.json()
                    if "detail" in data:
                        return {"error": "not_found", "detail": data["detail"]}
                    return {"success": True, "data": data}

                return {"error": "api_error", "status_code": response.status_code}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}

    async def get_chair_series_by_family_code(self, family_code: str) -> dict[str, Any]:
        """
        Get chair series for a specific family code.

        Args:
            family_code: The family code

        Returns:
            Dict containing chair series or error information
        """
        try:
            api_url = f"{self.base_url}/middleware/api/v1/products/chair-series"
            params = {"family_code": family_code}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, params=params)

                if response.status_code == 404:
                    return {"error": "not_found", "detail": "No chair series found"}

                if response.status_code == 200:
                    data = response.json()
                    if "detail" in data:
                        return {"error": "not_found", "detail": data["detail"]}
                    return {"success": True, "data": data}

                return {"error": "api_error", "status_code": response.status_code}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}

    async def get_product_series_by_series_list(self, series_list: list[str]) -> dict[str, Any]:
        """
        Get product series for multiple series descriptions.

        Args:
            series_list: List of series descriptions

        Returns:
            Dict containing product series or error information
        """
        try:
            api_url = f"{self.base_url}/middleware/api/v1/products/product-series"

            # Build query parameters with multiple series values
            params = [("series", series) for series in series_list]

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, params=params)

                if response.status_code == 404:
                    return {"error": "not_found", "detail": "No product series found"}

                if response.status_code == 200:
                    data = response.json()
                    if "detail" in data:
                        return {"error": "not_found", "detail": data["detail"]}
                    return {"success": True, "data": data}

                return {"error": "api_error", "status_code": response.status_code}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}

    async def vector_search_products(self, query: str, category_filter: str, limit: int = 3) -> dict[str, Any]:
        """
        Perform vector search for products.

        Args:
            query: Search query
            category_filter: Category to filter by
            limit: Maximum number of results

        Returns:
            Dict containing search results or error information
        """
        try:
            vector_search_url = "https://gfg-vector-search.labs.quant.ai/search"
            payload = {"query": query, "category_filter": category_filter, "limit": limit}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(vector_search_url, json=payload)

                if response.status_code != 200:
                    return {"error": "api_error", "status_code": response.status_code}

                data = response.json()
                return {"success": True, "data": data}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}

    async def get_decision_trees(self) -> dict[str, Any]:
        """
        Get all decision trees for category discovery.

        Returns:
            Dict containing decision tree data or error information
        """
        try:
            api_url = f"{self.base_url}/middleware/api/v1/products/decision-trees"

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url)

                if response.status_code == 404:
                    return {"error": "not_found", "detail": "Decision trees not found"}

                if response.status_code == 200:
                    data = response.json()
                    return {"success": True, "data": data}

                return {"error": "api_error", "status_code": response.status_code}

        except httpx.ConnectError as e:
            logger.error(f"Connection error: {e}")
            return {"error": "connection_error", "detail": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"error": "unexpected_error", "detail": str(e)}


# Global singleton instance
_middleware_api_client = None


def get_middleware_api() -> MiddlewareProductAPI:
    """Get or create the global middleware API client instance"""
    global _middleware_api_client
    if _middleware_api_client is None:
        _middleware_api_client = MiddlewareProductAPI()
    return _middleware_api_client
