from langgraph.checkpoint.memory import MemorySaver
from langgraph_swarm import create_swarm

from gfg.agents.category_discovery import create_category_discovery_agent
from gfg.agents.faq import create_faq_agent
from gfg.agents.product_suggestion import create_product_suggestion_agent
from gfg.state.checkpointer import get_checkpointer
from gfg.state.store import get_store
from gfg.utils.logger import get_logger

logger = get_logger(__name__)

# Global agent instance - initialized lazily after checkpointer setup
_gfg_agent = None


def create_gfg_agent(use_memory_checkpointer: bool = False):
    """Create and compile the GFG agent with checkpointer and store.

    Args:
        use_memory_checkpointer: If True, uses in-memory checkpointer (for dev/testing).
                                 If False, uses PostgreSQL checkpointer (for production).
                                 Default is False.

    Note: When use_memory_checkpointer=False (production mode), this should only be
    called after the checkpointer has been set up (i.e., after checkpointer.setup()
    has been awaited in the lifespan).
    """
    if use_memory_checkpointer:
        checkpointer = MemorySaver()
        logger.info("Using in-memory checkpointer for development")
    else:
        checkpointer = get_checkpointer()

    store = get_store()

    # Create agents with checkpointer and store
    product_suggestion_agent = create_product_suggestion_agent(checkpointer=checkpointer, store=store)
    category_discovery_agent = create_category_discovery_agent(checkpointer=checkpointer, store=store)
    faq_agent = create_faq_agent(checkpointer=checkpointer, store=store)

    swarm = create_swarm(
        [product_suggestion_agent, category_discovery_agent, faq_agent],
        default_active_agent="CategoryDiscoveryAgent",
    )

    gfg_agent = swarm.compile(checkpointer=checkpointer, store=store)
    logger.info("GFG Agent compiled successfully")
    return gfg_agent


def initialize_gfg_agent(use_memory_checkpointer: bool = False):
    """Initialize the global GFG agent instance.

    Args:
        use_memory_checkpointer: If True, uses in-memory checkpointer (for dev/testing/fallback).
        If False, uses PostgreSQL checkpointer (for production).
        Default is False.

    Must be called after checkpointer.setup() has been awaited (when using PostgreSQL).
    This is typically called during application lifespan startup.

    Raises:
        Exception: If agent creation fails, the exception is propagated to the caller.
    """
    global _gfg_agent
    if _gfg_agent is None:
        _gfg_agent = create_gfg_agent(use_memory_checkpointer=use_memory_checkpointer)
    return _gfg_agent


def get_gfg_agent():
    """Get the GFG agent instance.

    Raises:
        RuntimeError: If the agent hasn't been initialized yet.
    """
    if _gfg_agent is None:
        raise RuntimeError(
            "GFG agent has not been initialized. "
            "Call initialize_gfg_agent() after checkpointer.setup() in application lifespan."
        )
    return _gfg_agent


def reset_gfg_agent():
    """Reset the global GFG agent instance.

    This allows re-initialization with different settings (e.g., fallback to memory checkpointer).
    Should be called before re-initializing if the first initialization attempt failed.
    """
    global _gfg_agent
    _gfg_agent = None
    logger.info("GFG Agent reset")


def create_gfg_agent_dev():
    """Create the GFG agent for LangGraph dev server.

    This uses an in-memory checkpointer that doesn't require async setup,
    making it suitable for use with `langgraph dev` command.
    """
    return create_gfg_agent(use_memory_checkpointer=True)
