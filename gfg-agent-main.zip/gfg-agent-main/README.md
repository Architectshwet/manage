# GFG Agent

A multi-agent conversational AI system built with LangGraph Swarm architecture for Global Furniture Group. The system features intelligent agent handoffs between specialized agents for FAQ handling and subcategory discovery.

## Features

- **Swarm Architecture**: Multiple specialized agents that can hand off conversations to each other
- **FAQ Agent**: Handles frequently asked questions, complaints, and customer service issues
- **Subcategory Discovery Agent**: Discovers and categorizes user queries
- **PostgreSQL Persistence**: Conversation checkpointing and history storage
- **Langfuse Observability**: Built-in tracing and monitoring integration
- **Streaming Responses**: Real-time SSE (Server-Sent Events) streaming
- **Docker Support**: Full containerization with development and production configurations

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      GFG Agent Swarm                        │
│  ┌─────────────────────┐    ┌─────────────────────────┐    │
│  │  Subcategory        │◄──►│      FAQ Agent          │    │
│  │  Discovery Agent    │    │                         │    │
│  │  (Default Entry)    │    │  - Customer Service     │    │
│  │                     │    │  - Complaints           │    │
│  │  - Query Routing    │    │  - FAQ Responses        │    │
│  └─────────────────────┘    └─────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    PostgreSQL Database                       │
│  - Checkpointer (conversation state)                        │
│  - Conversation History                                      │
│  - Session Store                                            │
└─────────────────────────────────────────────────────────────┘
```

## Prerequisites

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) (recommended) or pip
- Docker & Docker Compose (for containerized deployment)
- PostgreSQL 15+ (or use Docker)
- OpenAI API key

## Quick Start

### 1. Clone and Setup

```bash
git clone <repository-url>
cd gfg-agent
```

### 2. Environment Configuration

Copy the example environment file and configure your settings:

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
# Required: OpenAI API Key
OPENAI_API_KEY=sk-your-openai-api-key

# PostgreSQL Configuration
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=gfg_db
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres

# Optional: Langfuse Observability
LANGFUSE_ENABLED=false
LANGFUSE_PUBLIC_KEY=your-public-key
LANGFUSE_SECRET_KEY=your-secret-key
LANGFUSE_HOST=https://cloud.langfuse.com
```

### 3. Install Dependencies

Using uv (recommended):

```bash
uv sync
```

Or using pip:

```bash
pip install -e .
```

### 4. Start the Application

#### Option A: Docker (Recommended for Development)

Start with PostgreSQL included:

```bash
docker-compose -f docker-compose.dev.yml up --build
```

#### Option B: Local Development

First, ensure PostgreSQL is running, then:

```bash
uv run uvicorn gfg.server:app --host 0.0.0.0 --port 8000 --reload
```

#### Option C: LangGraph Dev Server

For development with the LangGraph Studio UI:

```bash
langgraph dev
```

The API will be available at `http://localhost:8000`.

## API Endpoints

### Health Check

```bash
GET /health
```

Response:
```json
{"status": "ok"}
```

### Chat Stream

```bash
POST /chat/stream
Content-Type: application/json

{
  "input": {
    "messages": [
      {
        "role": "user",
        "content": [{"type": "text", "text": "Hello, I have a question about furniture"}]
      }
    ],
    "caller_number": "+1234567890"  // Optional
  },
  "thread_id": "optional-thread-id"  // Optional, auto-generated if not provided
}
```

Response: Server-Sent Events (SSE) stream with:
- `token`: Streaming text chunks
- `say`: Special messages from tools
- `end_of_response`: Stream completion marker

### Example Usage

```bash
curl -X POST http://localhost:8000/chat/stream \
  -H "Content-Type: application/json" \
  -d '{
    "input": {
      "messages": [
        {"role": "user", "content": [{"type": "text", "text": "What furniture categories do you have?"}]}
      ]
    }
  }'
```

## Project Structure

```
gfg-agent/
├── gfg/
│   ├── agents/                 # Agent definitions
│   │   ├── faq.py             # FAQ Agent
│   │   └── subcategory_discovery.py  # Subcategory Discovery Agent
│   ├── db/                     # Database layer
│   │   ├── db_singleton.py    # Connection pool singleton
│   │   ├── postgres_config.py # Database configuration
│   │   ├── postgres_repository.py  # Data access layer
│   │   └── postgres_session_sync.py  # Session sync service
│   ├── prompts/               # Agent system prompts
│   │   ├── faq_prompt.py
│   │   └── subcategory_discovery_prompt.py
│   ├── services/              # Business services
│   │   ├── langfuse_service.py  # Observability
│   │   └── postgres_db_service.py  # Conversation history
│   ├── state/                 # State management
│   │   ├── checkpointer.py    # PostgreSQL checkpointer
│   │   └── store.py           # In-memory store
│   ├── tools/                 # Agent tools
│   │   └── handoff_tools.py   # Agent handoff tools
│   ├── utils/                 # Utilities
│   │   └── logger.py          # Logging configuration
│   ├── gfg_agent.py           # Main agent orchestration
│   └── server.py              # FastAPI application
├── docker-compose.yml         # Production Docker config
├── docker-compose.dev.yml     # Development Docker config
├── Dockerfile                 # Container image definition
├── langgraph.json            # LangGraph configuration
├── pyproject.toml            # Project dependencies
└── test_gfg_agent.py         # Test suite
```

## Configuration Options

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENAI_API_KEY` | OpenAI API key (required) | - |
| `OPENAI_MODEL_FAQ` | Model for FAQ Agent | `gpt-4.1-mini` |
| `OPENAI_MODEL_SUBCATEGORY_DISCOVERY` | Model for Discovery Agent | `gpt-4.1` |
| `OPENAI_TEMPERATURE_FAQ` | Temperature for FAQ Agent | `0.3` |
| `OPENAI_TEMPERATURE_SUBCATEGORY_DISCOVERY` | Temperature for Discovery Agent | `0.2` |
| `POSTGRES_HOST` | PostgreSQL host | `localhost` |
| `POSTGRES_PORT` | PostgreSQL port | `5432` |
| `POSTGRES_DB` | Database name | `gfg_db` |
| `POSTGRES_USER` | Database user | `postgres` |
| `POSTGRES_PASSWORD` | Database password | `postgres` |
| `LANGFUSE_ENABLED` | Enable Langfuse observability | `false` |
| `LANGFUSE_PUBLIC_KEY` | Langfuse public key | - |
| `LANGFUSE_SECRET_KEY` | Langfuse secret key | - |
| `LANGFUSE_HOST` | Langfuse host URL | `https://cloud.langfuse.com` |
| `ENABLE_SESSION_SYNC` | Sync sessions to PostgreSQL | `false` |
| `LOG_LEVEL` | Logging level | `INFO` |
| `ENABLE_FILE_LOGGING` | Enable file-based logging | `false` |
| `LOG_FILE_PATH` | Log file path | `app.log` |

## Development

### Running Tests

```bash
uv run pytest test_gfg_agent.py -v
```

### Code Formatting & Linting

```bash
# Format code
uv run ruff format .

# Lint code
uv run ruff check .

# Lint and fix
uv run ruff check . --fix
```

### Adding New Agents

1. Create a new agent file in `gfg/agents/`
2. Define the system prompt in `gfg/prompts/`
3. Create handoff tools in `gfg/tools/handoff_tools.py`
4. Register the agent in `gfg/gfg_agent.py`

## Docker Deployment

### Development Mode

Includes hot-reload and PostgreSQL:

```bash
docker-compose -f docker-compose.dev.yml up --build
```

### Production Mode

Assumes external PostgreSQL:

```bash
docker-compose up --build -d
```

### Building the Image

```bash
docker build -t gfg-agent:latest .
```

## Observability

### Langfuse Integration

Enable Langfuse for tracing and monitoring:

1. Create a Langfuse account at [cloud.langfuse.com](https://cloud.langfuse.com)
2. Create a new project and get your API keys
3. Configure environment variables:
   ```env
   LANGFUSE_ENABLED=true
   LANGFUSE_PUBLIC_KEY=pk-...
   LANGFUSE_SECRET_KEY=sk-...
   ```

### Logging

Configure logging via environment variables:

```env
LOG_LEVEL=DEBUG  # DEBUG, INFO, WARNING, ERROR, CRITICAL
ENABLE_FILE_LOGGING=true
LOG_FILE_PATH=/var/log/gfg-agent.log
```

## Error Handling

The application implements graceful degradation:

- **PostgreSQL unavailable**: Falls back to in-memory checkpointer (no persistence)
- **Agent initialization failure**: Attempts fallback to memory checkpointer, fails fast if both fail
- **Langfuse unavailable**: Continues without observability

## Contributing

1. Create a feature branch
2. Make your changes
3. Run tests and linting
4. Submit a pull request

## Support

For issues and questions, contact the development team.
